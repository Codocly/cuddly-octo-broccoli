# COSMOS — Space Exploration AI Chatbot

> Ask anything about the universe. Powered by Claude.

**[Live Demo →](https://your-deployment.vercel.app)**

---

## What I Built

COSMOS is a purpose-built space exploration chatbot that answers questions about astronomy, astrophysics, space missions, and cosmology. It's designed to feel like a real product — not a generic chat wrapper — with UI and UX decisions made specifically for the space theme.

## Why Space?

Three reasons:
1. **Visually rich**: A dark, starfield-based UI with glowing accents is natural for the topic — not forced
2. **Rich knowledge domain**: From Apollo missions to dark matter, there's genuine depth to explore
3. **Emotional resonance**: Space genuinely excites people — that wonder comes through in every conversation

## Design Decisions

### The Experience
- **Empty state**: Animated orbital rings + 6 curated suggestion chips to help users start immediately — no blank page paralysis
- **Loading state**: Typing indicator with bouncing dots styled like stars; a spinning orbit ring on the send button
- **Error state**: On-theme message ("Signal lost") instead of generic error text
- **Status indicator**: Live/scanning dot in the header gives instant feedback on connection state

### The Visual Language
- Deep void background (`#04050f`) with a canvas-rendered animated starfield (220 stars, randomized twinkling)
- Color palette: indigo/violet accents (`#4f6ef7`, `#a78bfa`) against near-black
- Typography: **Playfair Display** for headings (adds gravitas), **Space Mono** for labels/branding (technical + space-y), **DM Sans** for body
- Nebula gradient overlays using radial gradients — subtle depth without noise
- Glassmorphism on header + input bar: `backdrop-filter: blur(12px)` over the starfield

### The AI Persona
COSMOS has a defined personality: enthusiastic astronomer, uses vivid scale comparisons, ends on wonder. This makes every response feel characterful vs. generic.

## Tech Stack

| Layer | Choice |
|-------|--------|
| Framework | Next.js 14 (App Router) |
| Styling | Tailwind CSS + custom CSS |
| AI | Vercel AI SDK + Anthropic Claude |
| Deployment | Vercel |

## Running Locally

```bash
git clone https://github.com/yourusername/cosmos-chatbot
cd cosmos-chatbot
npm install

# Add your Anthropic API key
cp .env.local.example .env.local
# Edit .env.local and add: ANTHROPIC_API_KEY=your_key_here

npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Deploying to Vercel

```bash
npx vercel
```

Set the `ANTHROPIC_API_KEY` environment variable in your Vercel project settings.

## Project Structure

```
cosmos/
├── app/
│   ├── api/chat/route.ts    # Streaming chat API with COSMOS system prompt
│   ├── page.tsx             # Main chat UI
│   ├── layout.tsx           # Root layout + metadata
│   └── globals.css          # Theme, animations, scrollbar, prose styles
├── components/
│   ├── Starfield.tsx        # Canvas-based animated star background
│   ├── ChatMessage.tsx      # Message bubbles + typing indicator
│   └── EmptyState.tsx       # Welcome screen + suggestion chips
└── README.md
```

---

*Built for Thinkly Labs software engineering assessment.*

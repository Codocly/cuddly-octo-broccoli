'use client'

import { useChat } from 'ai/react'
import { useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import ChatMessage, { TypingIndicator } from '@/components/ChatMessage'
import EmptyState from '@/components/EmptyState'

const Starfield = dynamic(() => import('@/components/Starfield'), { ssr: false })

export default function Home() {
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [inputFocused, setInputFocused] = useState(false)

  const { messages, input, handleInputChange, handleSubmit, isLoading, error, setInput, append } =
    useChat({
      api: '/api/chat',
    })

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  const handleSuggestion = (text: string) => {
    append({ role: 'user', content: text })
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      if (input.trim()) {
        handleSubmit(e as unknown as React.FormEvent)
      }
    }
  }

  const isEmpty = messages.length === 0

  return (
    <div className="nebula-bg" style={{ height: '100dvh', display: 'flex', flexDirection: 'column', position: 'relative' }}>
      <Starfield />

      {/* Header */}
      <header
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '14px 20px',
          borderBottom: '1px solid rgba(79,110,247,0.12)',
          background: 'rgba(4,5,15,0.7)',
          backdropFilter: 'blur(12px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          {/* Logo mark */}
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #4f6ef7 0%, #7c3aed 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '15px',
              boxShadow: '0 0 16px rgba(79,110,247,0.5)',
              flexShrink: 0,
            }}
          >
            ✦
          </div>
          <div>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '16px',
                fontWeight: '700',
                letterSpacing: '0.15em',
                color: '#e2e8ff',
                lineHeight: 1,
              }}
            >
              COSMOS
            </div>
            <div
              style={{
                fontSize: '10px',
                color: 'rgba(167,139,250,0.6)',
                letterSpacing: '0.1em',
                marginTop: '2px',
              }}
            >
              SPACE EXPLORATION AI
            </div>
          </div>
        </div>

        {/* Status indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <div
            style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              background: isLoading ? '#f59e0b' : '#22c55e',
              boxShadow: isLoading ? '0 0 6px rgba(245,158,11,0.8)' : '0 0 6px rgba(34,197,94,0.8)',
              transition: 'all 0.3s',
            }}
          />
          <span
            style={{
              fontSize: '11px',
              color: 'rgba(226,232,255,0.4)',
              fontFamily: 'var(--font-mono)',
            }}
          >
            {isLoading ? 'SCANNING...' : 'ONLINE'}
          </span>
        </div>
      </header>

      {/* Messages area */}
      <div
        className="messages-scroll"
        style={{
          flex: 1,
          overflowY: 'auto',
          position: 'relative',
          zIndex: 10,
          minHeight: 0,
        }}
      >
        {isEmpty ? (
          <EmptyState onSuggestion={handleSuggestion} />
        ) : (
          <div style={{ padding: '20px', maxWidth: '720px', margin: '0 auto' }}>
            {messages.map((m, i) => (
              <ChatMessage key={m.id} message={m} isLast={i === messages.length - 1} />
            ))}
            {isLoading && <TypingIndicator />}
            {error && (
              <div
                style={{
                  background: 'rgba(239,68,68,0.1)',
                  border: '1px solid rgba(239,68,68,0.3)',
                  borderRadius: '10px',
                  padding: '12px 16px',
                  fontSize: '13px',
                  color: '#fca5a5',
                  marginBottom: '16px',
                  display: 'flex',
                  gap: '8px',
                  alignItems: 'center',
                }}
              >
                <span>⚠</span>
                <span>Signal lost. Check your connection to the cosmos and try again.</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input area */}
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '12px 16px 16px',
          borderTop: '1px solid rgba(79,110,247,0.1)',
          background: 'rgba(4,5,15,0.8)',
          backdropFilter: 'blur(12px)',
          flexShrink: 0,
        }}
      >
        <div style={{ maxWidth: '720px', margin: '0 auto' }}>
          <form onSubmit={handleSubmit}>
            <div
              style={{
                display: 'flex',
                gap: '10px',
                alignItems: 'flex-end',
                background: 'rgba(13,16,53,0.8)',
                border: `1px solid ${inputFocused ? 'rgba(79,110,247,0.5)' : 'rgba(79,110,247,0.15)'}`,
                borderRadius: '14px',
                padding: '8px 8px 8px 16px',
                transition: 'border-color 0.2s, box-shadow 0.2s',
                boxShadow: inputFocused ? '0 0 0 3px rgba(79,110,247,0.1)' : 'none',
              }}
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onFocus={() => setInputFocused(true)}
                onBlur={() => setInputFocused(false)}
                placeholder="Ask anything about the universe..."
                disabled={isLoading}
                style={{
                  flex: 1,
                  background: 'transparent',
                  border: 'none',
                  outline: 'none',
                  color: '#e2e8ff',
                  fontSize: '14px',
                  lineHeight: '1.5',
                  fontFamily: 'var(--font-body)',
                  resize: 'none',
                  padding: '4px 0',
                  caretColor: '#4f6ef7',
                }}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '10px',
                  background:
                    input.trim() && !isLoading
                      ? 'linear-gradient(135deg, #4f6ef7 0%, #7c3aed 100%)'
                      : 'rgba(79,110,247,0.1)',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: input.trim() && !isLoading ? 'pointer' : 'not-allowed',
                  transition: 'all 0.2s',
                  flexShrink: 0,
                  color: input.trim() && !isLoading ? 'white' : 'rgba(79,110,247,0.3)',
                  fontSize: '16px',
                  boxShadow:
                    input.trim() && !isLoading ? '0 0 12px rgba(79,110,247,0.4)' : 'none',
                }}
              >
                {isLoading ? (
                  <div
                    className="orbit-ring"
                    style={{
                      width: '16px',
                      height: '16px',
                      borderRadius: '50%',
                      border: '2px solid rgba(79,110,247,0.3)',
                      borderTopColor: 'rgba(79,110,247,0.9)',
                      animation: 'orbit 0.8s linear infinite',
                    }}
                  />
                ) : (
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M2 8h10M8 4l6 4-6 4"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                )}
              </button>
            </div>
          </form>
          <div
            style={{
              textAlign: 'center',
              marginTop: '8px',
              fontSize: '10px',
              color: 'rgba(226,232,255,0.2)',
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.08em',
            }}
          >
            COSMOS • SPACE EXPLORATION AI • POWERED BY CLAUDE
          </div>
        </div>
      </div>
    </div>
  )
}

import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'COSMOS — Your Space Exploration Guide',
  description: 'Ask anything about the universe. Planets, black holes, missions, cosmology — COSMOS knows.',
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔭</text></svg>",
  },
  openGraph: {
    title: 'COSMOS — Your Space Exploration Guide',
    description: 'Ask anything about the universe.',
    type: 'website',
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}

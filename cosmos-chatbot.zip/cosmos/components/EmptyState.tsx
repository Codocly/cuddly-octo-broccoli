'use client'

const SUGGESTIONS = [
  { emoji: '🪐', text: 'How big is Jupiter compared to Earth?' },
  { emoji: '🕳️', text: 'What happens if you fall into a black hole?' },
  { emoji: '🌌', text: 'How did the universe begin?' },
  { emoji: '🔭', text: "What has the James Webb Telescope discovered?" },
  { emoji: '👽', text: 'Could there be life on Europa?' },
  { emoji: '☄️', text: 'How do we know the age of the universe?' },
]

interface EmptyStateProps {
  onSuggestion: (text: string) => void
}

export default function EmptyState({ onSuggestion }: EmptyStateProps) {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        padding: '2rem 1rem',
        textAlign: 'center',
      }}
    >
      {/* Animated telescope/orbit graphic */}
      <div style={{ position: 'relative', width: '80px', height: '80px', marginBottom: '2rem' }}>
        {/* Outer orbit ring */}
        <div
          style={{
            position: 'absolute',
            inset: '0',
            borderRadius: '50%',
            border: '1px solid rgba(79,110,247,0.2)',
            animation: 'orbit 8s linear infinite',
          }}
        />
        {/* Inner orbit ring */}
        <div
          style={{
            position: 'absolute',
            inset: '12px',
            borderRadius: '50%',
            border: '1px solid rgba(167,139,250,0.25)',
            animation: 'orbit 5s linear infinite reverse',
          }}
        />
        {/* Orbiting dot */}
        <div
          style={{
            position: 'absolute',
            top: '-3px',
            left: '50%',
            width: '6px',
            height: '6px',
            marginLeft: '-3px',
            background: '#4f6ef7',
            borderRadius: '50%',
            boxShadow: '0 0 8px rgba(79,110,247,0.8)',
            animation: 'orbit 8s linear infinite',
            transformOrigin: '3px 43px',
          }}
        />
        {/* Center star */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '28px',
          }}
        >
          ✦
        </div>
      </div>

      <h2
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: '22px',
          fontWeight: '400',
          color: '#e2e8ff',
          marginBottom: '8px',
          letterSpacing: '-0.02em',
        }}
      >
        What mysteries shall we explore?
      </h2>
      <p
        style={{
          fontSize: '13px',
          color: 'rgba(226,232,255,0.4)',
          marginBottom: '2rem',
          maxWidth: '320px',
          lineHeight: '1.6',
        }}
      >
        From the birth of stars to the edge of the observable universe — ask me anything.
      </p>

      {/* Suggestion chips */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '8px',
          width: '100%',
          maxWidth: '480px',
        }}
      >
        {SUGGESTIONS.map((s) => (
          <button
            key={s.text}
            onClick={() => onSuggestion(s.text)}
            className="suggestion-chip"
            style={{
              background: 'rgba(13, 16, 53, 0.6)',
              borderRadius: '10px',
              padding: '10px 12px',
              textAlign: 'left',
              cursor: 'pointer',
              color: 'rgba(226,232,255,0.75)',
              fontSize: '12px',
              lineHeight: '1.4',
              display: 'flex',
              gap: '8px',
              alignItems: 'flex-start',
            }}
          >
            <span style={{ fontSize: '14px', flexShrink: 0 }}>{s.emoji}</span>
            <span>{s.text}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

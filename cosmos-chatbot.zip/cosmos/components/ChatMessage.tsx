'use client'

import { Message } from 'ai'

function renderMarkdown(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/^### (.+)$/gm, '<h3 style="font-size:14px;font-weight:500;margin:0.8em 0 0.3em;color:#a78bfa">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="font-size:15px;font-weight:500;margin:0.8em 0 0.3em;color:#a78bfa">$1</h2>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]+?<\/li>)/g, (match) => `<ul style="padding-left:1.2em;margin:0.4em 0">${match}</ul>`)
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br/>')
}

interface ChatMessageProps {
  message: Message
  isLast?: boolean
}

export default function ChatMessage({ message, isLast }: ChatMessageProps) {
  const isUser = message.role === 'user'

  if (isUser) {
    return (
      <div className="message-enter flex justify-end mb-4">
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(79,110,247,0.25) 0%, rgba(79,110,247,0.15) 100%)',
            border: '1px solid rgba(79,110,247,0.3)',
            borderRadius: '18px 18px 4px 18px',
            padding: '10px 16px',
            maxWidth: '80%',
            color: '#e2e8ff',
            fontSize: '14px',
            lineHeight: '1.6',
          }}
        >
          {message.content}
        </div>
      </div>
    )
  }

  return (
    <div className="message-enter flex gap-3 mb-5">
      {/* COSMOS avatar */}
      <div
        style={{
          width: '32px',
          height: '32px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #4f6ef7 0%, #7c3aed 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '14px',
          flexShrink: 0,
          marginTop: '2px',
          boxShadow: '0 0 12px rgba(79,110,247,0.4)',
        }}
      >
        ✦
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: '10px',
            letterSpacing: '0.12em',
            color: 'rgba(167,139,250,0.7)',
            fontFamily: 'var(--font-mono)',
            marginBottom: '6px',
            textTransform: 'uppercase',
          }}
        >
          COSMOS
        </div>
        <div
          className="cosmos-prose"
          style={{
            color: 'rgba(226,232,255,0.9)',
            fontSize: '14px',
            lineHeight: '1.65',
          }}
          dangerouslySetInnerHTML={{
            __html: `<p>${renderMarkdown(message.content)}</p>`,
          }}
        />
      </div>
    </div>
  )
}

export function TypingIndicator() {
  return (
    <div className="message-enter flex gap-3 mb-5">
      <div
        style={{
          width: '32px',
          height: '32px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #4f6ef7 0%, #7c3aed 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '14px',
          flexShrink: 0,
          boxShadow: '0 0 12px rgba(79,110,247,0.4)',
        }}
      >
        ✦
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px', paddingTop: '8px' }}>
        <div className="typing-dot" />
        <div className="typing-dot" />
        <div className="typing-dot" />
      </div>
    </div>
  )
}
